class ClienteEspecial extends Cliente {
    private _dependentes : Array<Cliente>;
    constructor(nome: string, cpf: string, conta: Conta) {
        super(nome, cpf, conta);
        this._dependentes = Array<Cliente>();
    }

    get nome() {
        return this._nome;
    }

    set nome(nome) {
        this._nome = nome;
    }

    get cpf() {
        return this._cpf;
    }

    set cpf(value) {
        this._cpf = value;
    }

    get dependentes(){
        return this._dependentes;
    }
}